# data_preprocess_helper.py
import csv, json

def clean_stock_data(filepath):
    """주식 거래 내역 데이터 정제 및 수익 종목 필터링"""
    profitable = []
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if '+' in row.get('수익률(%)', ''):
                profitable.append(row)
    print(f"총 {len(profitable)}개 수익 종목 필터링 완료")
    return profitable

if __name__ == "__main__":
    print("데이터 전처리 유틸리티 모듈 준비 완료")
